# EduPlay Studio - Historical Dialogues Backend

This is the Django backend for the Historical Dialogues feature of EduPlay Studio.

## Setup

1. Clone the repository
2. Create a virtual environment: `python -m venv venv`
3. Activate the virtual environment:
   - Windows: `venv\Scripts\activate`
   - Unix/MacOS: `source venv/bin/activate`
4. Install dependencies: `pip install -r requirements.txt`
5. Copy `.env.example` to `.env` and configure your environment variables
6. Run migrations: `python manage.py migrate`
7. Load sample data: `python manage.py load_sample_data`
8. Create a superuser: `python manage.py createsuperuser`
9. Run the development server: `python manage.py runserver`

## API Endpoints

### Historical Characters

- `GET /api/characters/` - List all historical characters
- `GET /api/characters/{id}/` - Get details for a specific character
- `GET /api/characters/{id}/dialogue/` - Get dialogue scenario for a specific character

### User Progress

- `GET /api/progress/{user_id}/` - Get progress for a specific user
- `PUT /api/progress/{user_id}/` - Update progress for a specific user

## Admin Interface

The admin interface is available at `/admin/` and provides a way to manage:

- Historical characters
- Dialogue scenarios
- Responses and keywords
- Quizzes and options
- User progress

## Integration with Frontend

This backend is designed to work with the Next.js frontend. The frontend makes API calls to this backend to fetch character data, dialogue scenarios, and to update user progress.

