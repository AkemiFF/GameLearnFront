default_app_config = 'historical_dialogues.apps.HistoricalDialoguesConfig'

