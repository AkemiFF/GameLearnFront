"use client"

import { useRef, useEffect, useState, useMemo } from "react"
import * as THREE from "three"
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls"
import { useTheme } from "next-themes"
import { countries } from "@/data/countries"

interface Globe3DRendererProps {
  onCountrySelect: (countryCode: string) => void
  visitedCountries: string[]
  selectedCountry: string | null
  width?: number
  height?: number
  onLoaded?: () => void
}

export default function Globe3DRenderer({
  onCountrySelect,
  visitedCountries,
  selectedCountry,
  width = 800,
  height = 600,
  onLoaded,
}: Globe3DRendererProps) {
  console.log("Globe3D renderer initializing")
  const containerRef = useRef<HTMLDivElement>(null)
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null)
  const sceneRef = useRef<THREE.Scene | null>(null)
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null)
  const controlsRef = useRef<OrbitControls | null>(null)
  const earthRef = useRef<THREE.Mesh | null>(null)
  const markersRef = useRef<THREE.Group | null>(null)
  const raycasterRef = useRef<THREE.Raycaster>(new THREE.Raycaster())
  const mouseRef = useRef<THREE.Vector2>(new THREE.Vector2())

  const [isInitialized, setIsInitialized] = useState(false)
  const [hoveredCountry, setHoveredCountry] = useState<string | null>(null)
  const [tooltipPosition, setTooltipPosition] = useState<{ x: number; y: number } | null>(null)
  const [error, setError] = useState<string | null>(null)

  const { theme } = useTheme()
  const isDarkTheme = theme === "dark"

  // Country coordinates (latitude, longitude)
  const countryCoordinates = useMemo(
    () => ({
      FR: { lat: 46.2276, lng: 2.2137 },
      US: { lat: 37.0902, lng: -95.7129 },
      JP: { lat: 36.2048, lng: 138.2529 },
      BR: { lat: -14.235, lng: -51.9253 },
      AU: { lat: -25.2744, lng: 133.7751 },
      ZA: { lat: -30.5595, lng: 22.9375 },
      DE: { lat: 51.1657, lng: 10.4515 },
      IT: { lat: 41.8719, lng: 12.5674 },
      ES: { lat: 40.4637, lng: -3.7492 },
      GB: { lat: 55.3781, lng: -3.436 },
      CA: { lat: 56.1304, lng: -106.3468 },
      CN: { lat: 35.8617, lng: 104.1954 },
      IN: { lat: 20.5937, lng: 78.9629 },
      RU: { lat: 61.524, lng: 105.3188 },
      MX: { lat: 23.6345, lng: -102.5528 },
      EG: { lat: 26.8206, lng: 30.8025 },
      AR: { lat: -38.4161, lng: -63.6167 },
      NZ: { lat: -40.9006, lng: 174.886 },
      NG: { lat: 9.082, lng: 8.6753 },
      SE: { lat: 60.1282, lng: 18.6435 },
    }),
    [],
  )

  // Helper function to convert latitude/longitude to 3D position
  const latLngToVector3 = (lat: number, lng: number, radius: number) => {
    const phi = (90 - lat) * (Math.PI / 180)
    const theta = (lng + 180) * (Math.PI / 180)

    const x = -radius * Math.sin(phi) * Math.cos(theta)
    const y = radius * Math.cos(phi)
    const z = radius * Math.sin(phi) * Math.sin(theta)

    return new THREE.Vector3(x, y, z)
  }

  // Function to add country markers
  const addCountryMarkers = () => {
    if (!markersRef.current || !earthRef.current) return

    // Clear existing markers
    while (markersRef.current.children.length > 0) {
      markersRef.current.remove(markersRef.current.children[0])
    }

    // Add new markers
    Object.entries(countryCoordinates).forEach(([countryCode, coords]) => {
      const { lat, lng } = coords

      // Convert lat/lng to 3D position
      const position = latLngToVector3(lat, lng, 2.1)

      // Create marker
      const markerGeometry = new THREE.SphereGeometry(0.05, 16, 16)
      const markerMaterial = new THREE.MeshBasicMaterial({
        color: visitedCountries.includes(countryCode) ? 0x3b82f6 : 0xd1d5db,
      })

      const marker = new THREE.Mesh(markerGeometry, markerMaterial)
      marker.position.set(position.x, position.y, position.z)
      marker.userData = { countryCode }

      markersRef.current.add(marker)
    })
  }

  // Focus on a country
  const focusOnCountry = (countryCode: string) => {
    if (!earthRef.current || !cameraRef.current || !controlsRef.current) return

    const coords = countryCoordinates[countryCode as keyof typeof countryCoordinates]
    if (!coords) return

    const position = latLngToVector3(coords.lat, coords.lng, 5)

    // Animate camera position
    const startPosition = cameraRef.current.position.clone()
    const endPosition = position.clone()

    const duration = 1000 // ms
    const startTime = Date.now()

    const animate = () => {
      const elapsed = Date.now() - startTime
      const progress = Math.min(elapsed / duration, 1)

      // Ease function (ease-out)
      const easeProgress = 1 - Math.pow(1 - progress, 3)

      // Interpolate position
      cameraRef.current!.position.lerpVectors(startPosition, endPosition, easeProgress)

      // Look at the earth
      cameraRef.current!.lookAt(earthRef.current!.position)

      if (progress < 1) {
        requestAnimationFrame(animate)
      } else {
        // Update controls target
        controlsRef.current!.target.copy(earthRef.current!.position)
        controlsRef.current!.update()
      }
    }

    animate()
  }

  // Initialize Three.js scene
  useEffect(() => {
    if (!containerRef.current || isInitialized) return

    console.log("Initializing Three.js scene")

    try {
      // Create scene
      const scene = new THREE.Scene()
      sceneRef.current = scene

      // Create camera
      const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000)
      camera.position.z = 5
      cameraRef.current = camera

      // Create renderer
      const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true })
      renderer.setSize(width, height)
      renderer.setPixelRatio(window.devicePixelRatio)
      containerRef.current.appendChild(renderer.domElement)
      rendererRef.current = renderer

      // Add ambient light
      const ambientLight = new THREE.AmbientLight(0xffffff, 0.5)
      scene.add(ambientLight)

      // Add directional light
      const directionalLight = new THREE.DirectionalLight(0xffffff, 1)
      directionalLight.position.set(5, 3, 5)
      scene.add(directionalLight)

      // Créer une texture de base pour la Terre
      const createBasicTexture = (color: number) => {
        const canvas = document.createElement("canvas")
        canvas.width = 2
        canvas.height = 2
        const context = canvas.getContext("2d")
        if (context) {
          context.fillStyle = `#${color.toString(16).padStart(6, "0")}`
          context.fillRect(0, 0, 2, 2)
        }
        return new THREE.CanvasTexture(canvas)
      }

      // Créer Earth avec une texture de base
      const earthGeometry = new THREE.SphereGeometry(2, 64, 64)
      const earthMaterial = new THREE.MeshPhongMaterial({
        map: createBasicTexture(0x1a4d7c),
        specular: new THREE.Color(0x333333),
        shininess: 15,
      })

      const earth = new THREE.Mesh(earthGeometry, earthMaterial)
      scene.add(earth)
      earthRef.current = earth

      // Charger les textures de manière asynchrone
      const textureLoader = new THREE.TextureLoader()
      textureLoader.crossOrigin = "anonymous"

      // Charger la texture principale
      textureLoader.load(
        "/earth_texture.jpg",
        (texture) => {
          if (earthMaterial) {
            earthMaterial.map = texture
            earthMaterial.needsUpdate = true
          }
        },
        undefined,
        (error) => console.error("Error loading earth texture:", error),
      )

      // Charger la bump map
      textureLoader.load(
        "/earth_bump.jpg",
        (texture) => {
          if (earthMaterial) {
            earthMaterial.bumpMap = texture
            earthMaterial.bumpScale = 0.05
            earthMaterial.needsUpdate = true
          }
        },
        undefined,
        (error) => console.error("Error loading bump map:", error),
      )

      // Charger la specular map
      textureLoader.load(
        "/earth_specular.jpg",
        (texture) => {
          if (earthMaterial) {
            earthMaterial.specularMap = texture
            earthMaterial.needsUpdate = true
          }
        },
        undefined,
        (error) => console.error("Error loading specular map:", error),
      )

      // Create clouds
      const cloudGeometry = new THREE.SphereGeometry(2.05, 64, 64)
      const cloudMaterial = new THREE.MeshPhongMaterial({
        map: createBasicTexture(0xffffff),
        transparent: true,
        opacity: 0.2,
      })

      const clouds = new THREE.Mesh(cloudGeometry, cloudMaterial)
      scene.add(clouds)

      // Charger la texture des nuages
      textureLoader.load(
        "/earth_clouds.png",
        (texture) => {
          if (cloudMaterial) {
            cloudMaterial.map = texture
            cloudMaterial.opacity = 0.4
            cloudMaterial.needsUpdate = true
          }
        },
        undefined,
        (error) => console.error("Error loading clouds texture:", error),
      )

      // Create stars
      const starGeometry = new THREE.BufferGeometry()
      const starMaterial = new THREE.PointsMaterial({
        color: 0xffffff,
        size: 0.05,
      })

      const starVertices = []
      for (let i = 0; i < 10000; i++) {
        const x = (Math.random() - 0.5) * 2000
        const y = (Math.random() - 0.5) * 2000
        const z = (Math.random() - 0.5) * 2000
        starVertices.push(x, y, z)
      }

      starGeometry.setAttribute("position", new THREE.Float32BufferAttribute(starVertices, 3))
      const stars = new THREE.Points(starGeometry, starMaterial)
      scene.add(stars)

      // Create markers group
      const markersGroup = new THREE.Group()
      scene.add(markersGroup)
      markersRef.current = markersGroup

      // Add country markers
      addCountryMarkers()

      // Add orbit controls
      const controls = new OrbitControls(camera, renderer.domElement)
      controls.enableDamping = true
      controls.dampingFactor = 0.05
      controls.rotateSpeed = 0.5
      controls.minDistance = 3
      controls.maxDistance = 10
      controls.enablePan = false
      controlsRef.current = controls

      // Animation loop
      const animate = () => {
        requestAnimationFrame(animate)

        if (controlsRef.current) {
          controlsRef.current.update()
        }

        // Slowly rotate clouds
        if (clouds) {
          clouds.rotation.y += 0.0005
        }

        renderer.render(scene, camera)
      }

      animate()
      setIsInitialized(true)

      // Handle window resize
      const handleResize = () => {
        if (!containerRef.current || !cameraRef.current || !rendererRef.current) return

        const newWidth = containerRef.current.clientWidth
        const newHeight = containerRef.current.clientHeight

        cameraRef.current.aspect = newWidth / newHeight
        cameraRef.current.updateProjectionMatrix()

        rendererRef.current.setSize(newWidth, newHeight)
      }

      window.addEventListener("resize", handleResize)

      // Handle mouse move for raycasting
      const handleMouseMove = (event: MouseEvent) => {
        if (!containerRef.current || !cameraRef.current || !earthRef.current || !markersRef.current) return

        // Calculate mouse position in normalized device coordinates
        const rect = containerRef.current.getBoundingClientRect()
        mouseRef.current.x = ((event.clientX - rect.left) / rect.width) * 2 - 1
        mouseRef.current.y = -((event.clientY - rect.top) / rect.height) * 2 + 1

        // Update the raycaster
        raycasterRef.current.setFromCamera(mouseRef.current, cameraRef.current)

        // Check for intersections with markers
        const intersects = raycasterRef.current.intersectObjects(markersRef.current.children, true)

        if (intersects.length > 0) {
          const marker = intersects[0].object
          const countryCode = marker.userData?.countryCode

          if (countryCode && countryCode !== hoveredCountry) {
            setHoveredCountry(countryCode)
            setTooltipPosition({ x: event.clientX, y: event.clientY })

            // Highlight marker
            marker.scale.set(1.5, 1.5, 1.5)
          }
        } else if (hoveredCountry) {
          // Reset previously hovered marker
          const prevMarker = markersRef.current.children.find((child) => child.userData?.countryCode === hoveredCountry)

          if (prevMarker) {
            prevMarker.scale.set(1, 1, 1)
          }

          setHoveredCountry(null)
          setTooltipPosition(null)
        }
      }

      // Handle click for country selection
      const handleClick = (event: MouseEvent) => {
        if (!containerRef.current || !cameraRef.current || !earthRef.current || !markersRef.current) return

        // Calculate mouse position in normalized device coordinates
        const rect = containerRef.current.getBoundingClientRect()
        mouseRef.current.x = ((event.clientX - rect.left) / rect.width) * 2 - 1
        mouseRef.current.y = -((event.clientY - rect.top) / rect.height) * 2 + 1

        // Update the raycaster
        raycasterRef.current.setFromCamera(mouseRef.current, cameraRef.current)

        // Check for intersections with markers
        const intersects = raycasterRef.current.intersectObjects(markersRef.current.children, true)

        if (intersects.length > 0) {
          const marker = intersects[0].object
          const countryCode = marker.userData?.countryCode

          if (countryCode) {
            onCountrySelect(countryCode)
          }
        }
      }

      containerRef.current.addEventListener("mousemove", handleMouseMove)
      containerRef.current.addEventListener("click", handleClick)

      // Cleanup
      return () => {
        window.removeEventListener("resize", handleResize)

        if (containerRef.current) {
          containerRef.current.removeEventListener("mousemove", handleMouseMove)
          containerRef.current.removeEventListener("click", handleClick)
        }

        if (rendererRef.current && containerRef.current) {
          containerRef.current.removeChild(rendererRef.current.domElement)
          rendererRef.current.dispose()
        }
      }
    } catch (err) {
      console.error("Error initializing Three.js:", err)
      setError(err instanceof Error ? err.message : "Failed to initialize 3D globe")
    }
  }, [width, height, isInitialized, onCountrySelect, hoveredCountry, countryCoordinates])

  // Update markers when visited countries change
  useEffect(() => {
    if (!isInitialized || !markersRef.current) return

    // Update markers appearance based on visited status
    markersRef.current.children.forEach((marker) => {
      const countryCode = marker.userData?.countryCode

      if (countryCode) {
        const isVisited = visitedCountries.includes(countryCode)
        const isSelected = selectedCountry === countryCode

        // Update marker appearance
        if (isSelected) {
          // Selected country
          marker.material.color.set(0x9333ea) // purple-600
          marker.scale.set(1.5, 1.5, 1.5)
        } else if (isVisited) {
          // Visited country
          marker.material.color.set(0x3b82f6) // blue-500
          marker.scale.set(1, 1, 1)
        } else {
          // Unvisited country
          marker.material.color.set(0xd1d5db) // gray-300
          marker.scale.set(1, 1, 1)
        }
      }
    })
  }, [visitedCountries, selectedCountry, isInitialized])

  // Update theme
  useEffect(() => {
    if (!isInitialized || !sceneRef.current) return

    // Update background color based on theme
    if (isDarkTheme) {
      sceneRef.current.background = new THREE.Color(0x0f172a) // slate-900
    } else {
      sceneRef.current.background = new THREE.Color(0xeff6ff) // blue-50
    }
  }, [isDarkTheme, isInitialized])

  // Expose focusOnCountry method
  useEffect(() => {
    if (selectedCountry && isInitialized) {
      focusOnCountry(selectedCountry)
    }
  }, [selectedCountry, isInitialized])

  // Si une erreur s'est produite
  if (error) {
    return (
      <div className="flex items-center justify-center w-full h-full bg-muted/20">
        <div className="text-center p-4">
          <div className="text-red-500 mb-2">⚠️</div>
          <h3 className="text-lg font-medium mb-2">Impossible de charger le globe 3D</h3>
          <p className="text-sm text-muted-foreground mb-4">
            Votre navigateur ne semble pas prendre en charge WebGL ou une erreur s'est produite.
          </p>
          <p className="text-xs text-muted-foreground">Erreur: {error}</p>
        </div>
      </div>
    )
  }

  // Si le composant n'est pas encore initialisé
  if (!isInitialized) {
    return (
      <div className="flex items-center justify-center w-full h-full bg-muted/20">
        <div className="text-center p-4">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-current border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"></div>
          <p className="mt-2">Chargement du globe...</p>
          <p className="text-xs text-muted-foreground mt-1">
            Si le globe ne s'affiche pas, vérifiez que WebGL est activé dans votre navigateur.
          </p>
        </div>
      </div>
    )
  }

  return (
    <div className="relative w-full h-full">
      <div ref={containerRef} className="w-full h-full" />

      {/* Country tooltip */}
      {hoveredCountry && tooltipPosition && (
        <div
          className="absolute z-10 bg-background border rounded-md shadow-md p-2 text-sm pointer-events-none"
          style={{
            left: tooltipPosition.x + 10,
            top: tooltipPosition.y + 10,
          }}
        >
          {countries.find((c) => c.code === hoveredCountry)?.name || ""}
        </div>
      )}
    </div>
  )
}

