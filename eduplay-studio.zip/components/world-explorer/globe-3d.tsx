"use client"

import { useEffect } from "react"
import dynamic from "next/dynamic"

// Importation dynamique de Three.js pour éviter les problèmes de SSR
const Globe3DRenderer = dynamic(() => import("./globe-3d-renderer"), {
  ssr: false,
  loading: () => (
    <div className="flex items-center justify-center w-full h-full bg-muted/20">
      <div className="text-center p-4">
        <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-current border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"></div>
        <p className="mt-2">Chargement du globe...</p>
        <p className="text-xs text-muted-foreground mt-1">
          Si le globe ne s'affiche pas, vérifiez que WebGL est activé dans votre navigateur.
        </p>
      </div>
    </div>
  ),
})

interface Globe3DProps {
  onCountrySelect: (countryCode: string) => void
  visitedCountries: string[]
  selectedCountry: string | null
  width?: number
  height?: number
  onLoaded?: () => void
}

export function Globe3D(props: Globe3DProps) {
  // Notifier immédiatement que le composant est chargé
  // Le vrai chargement sera géré par le renderer
  useEffect(() => {
    if (props.onLoaded) {
      // Petit délai pour éviter les problèmes de rendu
      const timer = setTimeout(() => {
        props.onLoaded?.()
      }, 500)
      return () => clearTimeout(timer)
    }
  }, [props.onLoaded])

  return <Globe3DRenderer {...props} />
}

