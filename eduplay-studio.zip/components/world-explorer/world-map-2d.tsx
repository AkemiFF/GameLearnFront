"use client"

import { useEffect, useState, useRef } from "react"
import { MapContainer, TileLayer, GeoJSON, Marker, Popup, useMap } from "react-leaflet"
import L from "leaflet"
import "leaflet/dist/leaflet.css"
import { Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { countries } from "@/data/countries"
import { useMobile } from "@/hooks/use-mobile"

// Fix Leaflet icon issues in Next.js
useEffect(() => {
  // Only run on client side
  if (typeof window !== "undefined") {
    // @ts-ignore
    delete L.Icon.Default.prototype._getIconUrl
    L.Icon.Default.mergeOptions({
      iconRetinaUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png",
      iconUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png",
      shadowUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png",
    })
  }
}, [])

// Component to control map view
function MapController({
  center,
  zoom,
  countryCode,
}: {
  center?: [number, number]
  zoom?: number
  countryCode?: string | null
}) {
  const map = useMap()

  useEffect(() => {
    if (center && zoom) {
      map.setView(center, zoom)
    }
  }, [center, zoom, map])

  return null
}

// Custom marker icon for visited countries
const createCustomIcon = (color: string) => {
  return new L.Icon({
    iconUrl: `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="${encodeURIComponent(color)}" width="24" height="24"><circle cx="12" cy="12" r="10" /></svg>`,
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, -12],
  })
}

interface WorldMap2DProps {
  onCountrySelect: (countryCode: string) => void
  visitedCountries: string[]
  selectedCountry: string | null
}

export function WorldMap2D({ onCountrySelect, visitedCountries, selectedCountry }: WorldMap2DProps) {
  const isMobile = useMobile()
  const mapRef = useRef<L.Map | null>(null)

  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState<typeof countries>([])
  const [mapCenter, setMapCenter] = useState<[number, number]>([20, 0])
  const [mapZoom, setMapZoom] = useState(2)
  const [geoJsonData, setGeoJsonData] = useState<any>(null)
  const [countryMarkers, setCountryMarkers] = useState<{ code: string; lat: number; lng: number }[]>([])

  // Handle search
  useEffect(() => {
    if (searchQuery.trim() === "") {
      setSearchResults([])
      return
    }

    const query = searchQuery.toLowerCase()
    const results = countries.filter((country) => country.name.toLowerCase().includes(query)).slice(0, 5)

    setSearchResults(results)
  }, [searchQuery])

  // Load GeoJSON data for country boundaries
  useEffect(() => {
    fetch("/api/country-boundaries")
      .then((response) => response.json())
      .then((data) => {
        setGeoJsonData(data)
      })
      .catch((error) => {
        console.error("Error loading country boundaries:", error)
        // Fallback to markers only if GeoJSON fails to load
        const markers = countries.map((country) => {
          const coords = getCountryCoordinates(country.code)
          return {
            code: country.code,
            lat: coords[0],
            lng: coords[1],
          }
        })
        setCountryMarkers(markers)
      })
  }, [])

  // Focus on selected country
  useEffect(() => {
    if (selectedCountry) {
      const coords = getCountryCoordinates(selectedCountry)
      setMapCenter(coords)
      setMapZoom(5)
    }
  }, [selectedCountry])

  // Get coordinates for a country
  const getCountryCoordinates = (countryCode: string): [number, number] => {
    const countryCoordinates: Record<string, [number, number]> = {
      FR: [46.2276, 2.2137],
      US: [37.0902, -95.7129],
      JP: [36.2048, 138.2529],
      BR: [-14.235, -51.9253],
      AU: [-25.2744, 133.7751],
      ZA: [-30.5595, 22.9375],
      DE: [51.1657, 10.4515],
      IT: [41.8719, 12.5674],
      ES: [40.4637, -3.7492],
      GB: [55.3781, -3.436],
      CA: [56.1304, -106.3468],
      CN: [35.8617, 104.1954],
      IN: [20.5937, 78.9629],
      RU: [61.524, 105.3188],
      MX: [23.6345, -102.5528],
      EG: [26.8206, 30.8025],
      AR: [-38.4161, -63.6167],
      NZ: [-40.9006, 174.886],
      NG: [9.082, 8.6753],
      SE: [60.1282, 18.6435],
    }

    return countryCoordinates[countryCode] || [0, 0]
  }

  // Style function for GeoJSON
  const countryStyle = (feature: any) => {
    const countryCode = feature.properties.ISO_A2

    if (selectedCountry === countryCode) {
      return {
        fillColor: "#9333ea", // purple-600
        weight: 2,
        opacity: 1,
        color: "#ffffff",
        fillOpacity: 0.7,
      }
    } else if (visitedCountries.includes(countryCode)) {
      return {
        fillColor: "#3b82f6", // blue-500
        weight: 1,
        opacity: 1,
        color: "#ffffff",
        fillOpacity: 0.5,
      }
    } else {
      return {
        fillColor: "#d1d5db", // gray-300
        weight: 1,
        opacity: 1,
        color: "#ffffff",
        fillOpacity: 0.5,
      }
    }
  }

  // Handle click on country
  const onEachFeature = (feature: any, layer: L.Layer) => {
    const countryCode = feature.properties.ISO_A2
    const countryName = feature.properties.NAME || countries.find((c) => c.code === countryCode)?.name || countryCode

    layer.on({
      click: () => {
        onCountrySelect(countryCode)
      },
      mouseover: (e) => {
        const layer = e.target
        layer.setStyle({
          weight: 3,
          color: "#ffffff",
          fillOpacity: 0.7,
        })
        layer.bindTooltip(countryName).openTooltip()
      },
      mouseout: (e) => {
        const layer = e.target
        layer.setStyle(countryStyle(feature))
        layer.closeTooltip()
      },
    })
  }

  return (
    <div className="relative w-full h-full">
      {/* Search bar */}
      <div className="absolute top-4 left-4 z-10 w-64">
        <div className="relative">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Rechercher un pays..."
            className="pl-8 pr-4 h-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />

          {searchResults.length > 0 && (
            <div className="absolute top-full left-0 right-0 mt-1 bg-background border rounded-md shadow-lg z-20">
              {searchResults.map((country) => (
                <div
                  key={country.code}
                  className="flex items-center gap-2 p-2 hover:bg-muted cursor-pointer"
                  onClick={() => {
                    const coords = getCountryCoordinates(country.code)
                    setMapCenter(coords)
                    setMapZoom(5)
                    setSearchQuery("")
                    setSearchResults([])
                  }}
                >
                  <div className="w-6 h-4 overflow-hidden rounded">
                    <img
                      src={`https://flagcdn.com/w80/${country.code.toLowerCase()}.png`}
                      alt={`Drapeau ${country.name}`}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <span className="text-sm">{country.name}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Map controls */}
      <div className="absolute top-4 right-4 z-10 flex flex-col gap-2">
        <Button variant="outline" size="icon" onClick={() => setMapZoom((prev) => Math.min(prev + 1, 8))}>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="h-4 w-4"
          >
            <circle cx="11" cy="11" r="8" />
            <line x1="21" x2="16.65" y1="21" y2="16.65" />
            <line x1="11" x2="11" y1="8" y2="14" />
            <line x1="8" x2="14" y1="11" y2="11" />
          </svg>
        </Button>
        <Button variant="outline" size="icon" onClick={() => setMapZoom((prev) => Math.max(prev - 1, 1))}>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="h-4 w-4"
          >
            <circle cx="11" cy="11" r="8" />
            <line x1="21" x2="16.65" y1="21" y2="16.65" />
            <line x1="8" x2="14" y1="11" y2="11" />
          </svg>
        </Button>
        <Button
          variant="outline"
          size="icon"
          onClick={() => {
            setMapCenter([20, 0])
            setMapZoom(2)
          }}
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="h-4 w-4"
          >
            <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
            <path d="M3 3v5h5" />
          </svg>
        </Button>
      </div>

      {/* Leaflet Map */}
      <MapContainer
        center={mapCenter}
        zoom={mapZoom}
        style={{ height: "100%", width: "100%", background: "#f0f8ff" }}
        zoomControl={false}
        whenCreated={(map) => {
          mapRef.current = map
        }}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        <MapController center={mapCenter} zoom={mapZoom} countryCode={selectedCountry} />

        {geoJsonData && <GeoJSON data={geoJsonData} style={countryStyle} onEachFeature={onEachFeature} />}

        {/* Fallback to markers if GeoJSON is not available */}
        {!geoJsonData &&
          countryMarkers.map((marker) => {
            const country = countries.find((c) => c.code === marker.code)
            const isVisited = visitedCountries.includes(marker.code)
            const isSelected = selectedCountry === marker.code

            const markerIcon = createCustomIcon(isSelected ? "#9333ea" : isVisited ? "#3b82f6" : "#d1d5db")

            return (
              <Marker
                key={marker.code}
                position={[marker.lat, marker.lng]}
                icon={markerIcon}
                eventHandlers={{
                  click: () => {
                    onCountrySelect(marker.code)
                  },
                }}
              >
                <Popup>
                  <div className="flex flex-col items-center p-1">
                    {country && (
                      <>
                        <div className="w-8 h-5 mb-1 overflow-hidden rounded">
                          <img
                            src={`https://flagcdn.com/w80/${country.code.toLowerCase()}.png`}
                            alt={`Drapeau ${country.name}`}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <span className="font-medium">{country.name}</span>
                      </>
                    )}
                  </div>
                </Popup>
              </Marker>
            )
          })}
      </MapContainer>

      {/* Fallback for mobile or when map isn't available */}
      {isMobile && !geoJsonData && countryMarkers.length === 0 && (
        <div className="absolute inset-0 flex items-center justify-center bg-muted/50 backdrop-blur-sm">
          <div className="text-center p-4">
            <p className="mb-4 text-muted-foreground">Sélectionnez un pays dans la liste ci-dessous:</p>
            <div className="grid grid-cols-2 gap-2 max-h-[300px] overflow-y-auto">
              {countries.map((country) => (
                <div
                  key={country.code}
                  className={`flex items-center gap-2 p-2 rounded-md cursor-pointer ${
                    visitedCountries.includes(country.code)
                      ? "bg-blue-100 dark:bg-blue-900/30"
                      : "bg-card hover:bg-muted"
                  }`}
                  onClick={() => onCountrySelect(country.code)}
                >
                  <div className="w-6 h-4 overflow-hidden rounded">
                    <img
                      src={`https://flagcdn.com/w80/${country.code.toLowerCase()}.png`}
                      alt={`Drapeau ${country.name}`}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <span className="text-sm truncate">{country.name}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

